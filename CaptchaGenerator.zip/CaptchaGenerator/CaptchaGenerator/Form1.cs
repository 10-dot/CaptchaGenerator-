using System;
using System.Windows.Forms;

namespace CaptchaGenerator
{
    public partial class Form1 : Form
    {
        private string correctAnswer; // Store the correct CAPTCHA answer
        private Random random = new Random(); // For generating CAPTCHAs
        private bool[] correctImageSelections; // For Image-Based CAPTCHA

        public Form1()
        {
            InitializeComponent();
            InitializeCaptchaTypes();
            GenerateCaptcha(); // Generate a CAPTCHA on form load
        }

        private void InitializeCaptchaTypes()
        {
            cmbCaptchaType.Items.AddRange(new string[] { "Text-Based", "Image-Based", "Math-Based", "Checkbox" });
            cmbCaptchaType.SelectedIndex = 0; // Default to Text-Based
        }

        private void GenerateCaptcha()
        {
            lblResult.Text = ""; // Clear previous result
            txtUserInput.Text = ""; // Clear user input
            chkVerify.Checked = false; // Reset checkbox
            lblInstructions.Text = "Please solve the CAPTCHA below:";

            // Hide all specific controls initially
            txtUserInput.Visible = false;
            chkVerify.Visible = false;
            picImage1.Visible = false;
            picImage2.Visible = false;
            picImage3.Visible = false;
            chkImage1.Visible = false;
            chkImage2.Visible = false;
            chkImage3.Visible = false;

            string selectedType = cmbCaptchaType.SelectedItem.ToString();
            lblCaptcha.Text = ""; // Clear CAPTCHA display

            if (selectedType == "Text-Based")
            {
                txtUserInput.Visible = true;
                // Generate a random 6-character alphanumeric string
                string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                char[] captcha = new char[6];
                for (int i = 0; i < 6; i++)
                {
                    captcha[i] = chars[random.Next(chars.Length)];
                }
                correctAnswer = new string(captcha);
                lblCaptcha.Text = correctAnswer;
            }
            else if (selectedType == "Image-Based")
            {
                lblInstructions.Text = "Select all items that are 'Fruits':";
                picImage1.Visible = true;
                picImage2.Visible = true;
                picImage3.Visible = true;
                chkImage1.Visible = true;
                chkImage2.Visible = true;
                chkImage3.Visible = true;

                // Load images from resources
                try
                {
                    // Try using the resource names as defined in the original code (Apple, Car, Banana)
                    picImage1.Image = Properties.Resources.Apple;  // Apple (Fruit)
                    picImage2.Image = Properties.Resources.Car;    // Car (Not a fruit)
                    picImage3.Image = Properties.Resources.Banana; // Banana (Fruit)
                }
                catch (Exception ex)
                {
                    // If the above fails, try lowercase names (apple, car, banana)
                    try
                    {
                        picImage1.Image = Properties.Resources.Apple;
                        picImage2.Image = Properties.Resources.Car;
                        picImage3.Image = Properties.Resources.Banana;
                    }
                    catch (Exception ex2)
                    {
                        MessageBox.Show($"Error loading images:\nOriginal attempt (Apple, Car, Banana): {ex.Message}\nSecond attempt (apple, car, banana): {ex2.Message}\nPlease ensure images are added to project resources with the correct names (Apple, Car, Banana or apple, car, banana).");
                        lblInstructions.Text = "Error: Images not found. Check resources.";
                        return;
                    }
                }

                correctImageSelections = new bool[] { true, false, true }; // Apple and Banana are correct
                chkImage1.Checked = false;
                chkImage2.Checked = false;
                chkImage3.Checked = false;
            }
            else if (selectedType == "Math-Based")
            {
                txtUserInput.Visible = true;
                // Generate a simple math problem (e.g., 5 + 3)
                int num1 = random.Next(1, 10);
                int num2 = random.Next(1, 10);
                correctAnswer = (num1 + num2).ToString();
                lblCaptcha.Text = $"{num1} + {num2} = ?";
            }
            else if (selectedType == "Checkbox")
            {
                chkVerify.Visible = true;
                lblCaptcha.Text = "I'm not a robot";
                // In a real reCAPTCHA, this would involve API validation
                correctAnswer = "verified";
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string selectedType = cmbCaptchaType.SelectedItem.ToString();
            lblResult.Text = "";

            if (selectedType == "Text-Based" || selectedType == "Math-Based")
            {
                if (txtUserInput.Text == correctAnswer)
                {
                    lblResult.Text = "Success!";
                    lblResult.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    lblResult.Text = "Error: Incorrect CAPTCHA";
                    lblResult.ForeColor = System.Drawing.Color.Red;
                }
            }
            else if (selectedType == "Image-Based")
            {
                bool isCorrect = chkImage1.Checked == correctImageSelections[0] &&
                                 chkImage2.Checked == correctImageSelections[1] &&
                                 chkImage3.Checked == correctImageSelections[2];

                if (isCorrect)
                {
                    lblResult.Text = "Success!";
                    lblResult.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    lblResult.Text = "Error: Incorrect selections";
                    lblResult.ForeColor = System.Drawing.Color.Red;
                }
            }
            else if (selectedType == "Checkbox")
            {
                if (chkVerify.Checked)
                {
                    lblResult.Text = "Success!";
                    lblResult.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    lblResult.Text = "Error: Please verify";
                    lblResult.ForeColor = System.Drawing.Color.Red;
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            GenerateCaptcha();
        }

        private void cmbCaptchaType_SelectedIndexChanged(object sender, EventArgs e)
        {
            GenerateCaptcha();
        }
    }
}