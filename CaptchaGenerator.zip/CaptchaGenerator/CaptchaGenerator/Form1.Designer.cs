﻿namespace CaptchaGenerator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            // Form settings
            this.Size = new System.Drawing.Size(400, 400); // Increased height to accommodate images
            this.Text = "CAPTCHA Generator";

            // Initialize controls
            this.lblInstructions = new System.Windows.Forms.Label();
            this.cmbCaptchaType = new System.Windows.Forms.ComboBox();
            this.lblCaptcha = new System.Windows.Forms.Label();
            this.txtUserInput = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.lblResult = new System.Windows.Forms.Label();
            this.chkVerify = new System.Windows.Forms.CheckBox();
            this.picImage1 = new System.Windows.Forms.PictureBox();
            this.picImage2 = new System.Windows.Forms.PictureBox();
            this.picImage3 = new System.Windows.Forms.PictureBox();
            this.chkImage1 = new System.Windows.Forms.CheckBox();
            this.chkImage2 = new System.Windows.Forms.CheckBox();
            this.chkImage3 = new System.Windows.Forms.CheckBox();

            ((System.ComponentModel.ISupportInitialize)(this.picImage1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picImage2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picImage3)).BeginInit();

            // lblInstructions
            this.lblInstructions.AutoSize = true;
            this.lblInstructions.Location = new System.Drawing.Point(20, 20);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Text = "Please solve the CAPTCHA below:";

            // cmbCaptchaType
            this.cmbCaptchaType.Location = new System.Drawing.Point(20, 50);
            this.cmbCaptchaType.Name = "cmbCaptchaType";
            this.cmbCaptchaType.Size = new System.Drawing.Size(150, 21);
            this.cmbCaptchaType.SelectedIndexChanged += new System.EventHandler(this.cmbCaptchaType_SelectedIndexChanged);

            // lblCaptcha
            this.lblCaptcha.AutoSize = true;
            this.lblCaptcha.Location = new System.Drawing.Point(20, 90);
            this.lblCaptcha.Name = "lblCaptcha";
            this.lblCaptcha.Text = "";

            // txtUserInput (for Text-Based and Math-Based)
            this.txtUserInput.Location = new System.Drawing.Point(20, 120);
            this.txtUserInput.Name = "txtUserInput";
            this.txtUserInput.Size = new System.Drawing.Size(150, 20);
            this.txtUserInput.Visible = false;

            // chkVerify (for Checkbox CAPTCHA)
            this.chkVerify.Location = new System.Drawing.Point(20, 120);
            this.chkVerify.Name = "chkVerify";
            this.chkVerify.Text = "";
            this.chkVerify.AutoSize = true;
            this.chkVerify.Visible = false;

            // Image-Based CAPTCHA controls (using PictureBox for images)
            this.picImage1.Location = new System.Drawing.Point(20, 120);
            this.picImage1.Name = "picImage1";
            this.picImage1.Size = new System.Drawing.Size(60, 60);
            this.picImage1.SizeMode = PictureBoxSizeMode.StretchImage;
            this.picImage1.Visible = false;

            this.picImage2.Location = new System.Drawing.Point(100, 120);
            this.picImage2.Name = "picImage2";
            this.picImage2.Size = new System.Drawing.Size(60, 60);
            this.picImage2.SizeMode = PictureBoxSizeMode.StretchImage;
            this.picImage2.Visible = false;

            this.picImage3.Location = new System.Drawing.Point(180, 120);
            this.picImage3.Name = "picImage3";
            this.picImage3.Size = new System.Drawing.Size(60, 60);
            this.picImage3.SizeMode = PictureBoxSizeMode.StretchImage;
            this.picImage3.Visible = false;

            this.chkImage1.Location = new System.Drawing.Point(20, 190);
            this.chkImage1.Name = "chkImage1";
            this.chkImage1.Text = "";
            this.chkImage1.AutoSize = true;
            this.chkImage1.Visible = false;

            this.chkImage2.Location = new System.Drawing.Point(100, 190);
            this.chkImage2.Name = "chkImage2";
            this.chkImage2.Text = "";
            this.chkImage2.AutoSize = true;
            this.chkImage2.Visible = false;

            this.chkImage3.Location = new System.Drawing.Point(180, 190);
            this.chkImage3.Name = "chkImage3";
            this.chkImage3.Text = "";
            this.chkImage3.AutoSize = true;
            this.chkImage3.Visible = false;

            // btnSubmit
            this.btnSubmit.Location = new System.Drawing.Point(20, 220);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(70, 23);
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);

            // btnRefresh
            this.btnRefresh.Location = new System.Drawing.Point(100, 220);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(100, 23);
            this.btnRefresh.Text = "Refresh CAPTCHA";
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);

            // lblResult
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(20, 260);
            this.lblResult.Name = "lblResult";
            this.lblResult.Text = "";

            // Add controls to the form
            this.Controls.Add(this.lblInstructions);
            this.Controls.Add(this.cmbCaptchaType);
            this.Controls.Add(this.lblCaptcha);
            this.Controls.Add(this.txtUserInput);
            this.Controls.Add(this.chkVerify);
            this.Controls.Add(this.picImage1);
            this.Controls.Add(this.picImage2);
            this.Controls.Add(this.picImage3);
            this.Controls.Add(this.chkImage1);
            this.Controls.Add(this.chkImage2);
            this.Controls.Add(this.chkImage3);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.lblResult);

            ((System.ComponentModel.ISupportInitialize)(this.picImage1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picImage2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picImage3)).EndInit();
        }

        #endregion

        private System.Windows.Forms.Label lblInstructions;
        private System.Windows.Forms.ComboBox cmbCaptchaType;
        private System.Windows.Forms.Label lblCaptcha;
        private System.Windows.Forms.TextBox txtUserInput;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.CheckBox chkVerify;
        private System.Windows.Forms.PictureBox picImage1;
        private System.Windows.Forms.PictureBox picImage2;
        private System.Windows.Forms.PictureBox picImage3;
        private System.Windows.Forms.CheckBox chkImage1;
        private System.Windows.Forms.CheckBox chkImage2;
        private System.Windows.Forms.CheckBox chkImage3;
    }
}